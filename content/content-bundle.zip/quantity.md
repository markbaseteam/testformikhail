is half-filled with a
is full of a
is 3/4 filled with a 
is 1/4 filled with a 

