tight-fitting
loose-fitting
wired shut
wax sealed 