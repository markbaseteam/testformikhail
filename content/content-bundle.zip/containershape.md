vial
flagon
flask
bottle
jar
jug
amphora