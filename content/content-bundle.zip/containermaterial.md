ceramic
glass
porcelain
crystal
soapstone
steel
brass
copper
golden
wooden
leather
rose quartz
silver
mithral
tin
smoky quartz
obsidian
pewter
horn
ivory 
jade
bamboo
skull
bladder
clay
nut shell
seashell
canvas
lead alloy
gourd
bronze
malachite